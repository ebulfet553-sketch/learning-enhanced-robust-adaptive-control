if ~exist('seed','var')
    seed = 1;
end

rng(seed);
dt = 0.001;
T = 10;

t = 0:dt:T;
N = length(t);

x = zeros(5,N);

% Initial condition
x(:,1) = [0; 0.5; 0.5; 0; 1];

% Sensor degradation starts at 5 seconds
degradation_time = 5;

bias = [0.05;
       -0.05];

% Controller parameters
Lambda = diag([6 6]);
Ks = diag([8 8]);

gamma = 0.5;
sigma = 0.5;

phi = 0.05;

khat_min = 0;
khat_max = 30;

torque_max = 20;

for k = 1:N-1

    % True state
    q_true = x(1:2,k);
    dq_true = x(3:4,k);

    % Sensor measurement
    q_meas = q_true;
    dq_meas = dq_true;

    % Apply sensor degradation after 5 s
    if t(k) >= degradation_time
        q_meas = q_meas + bias;
    end

    % Desired trajectory
    qd = [0.5*sin(t(k));
          0.5*cos(t(k))];

    dqd = [0.5*cos(t(k));
          -0.5*sin(t(k))];

    ddqd = [-0.5*sin(t(k));
            -0.5*cos(t(k))];

    % Tracking error
    e = q_meas - qd;
    de = dq_meas - dqd;

    % Sliding surface
    s = de + Lambda*e;

    % Robot parameters
    m1 = 1.70;
    m2 = 2.00;

    l1 = 0.41;
    l2 = 0.41;

    I1 = 0.25*m1*l1^2;
    I2 = 0.25*m2*l2^2;

    g = 9.8;

    q1 = q_true(1);
    q2 = q_true(2);

    dq1 = dq_true(1);
    dq2 = dq_true(2);

    % Actual dynamics
    M11 = m1*l1^2 + m2*(l1^2+l2^2 ...
        + 2*l1*l2*cos(q2)) + I1 + I2;

    M12 = m2*(l2^2+l1*l2*cos(q2)) + I2;

    M22 = m2*l2^2 + I2;

    M = [M11 M12;
         M12 M22];

    C = [-m2*l1*l2*dq2*sin(q2), ...
         -m2*l1*l2*(dq1+dq2)*sin(q2);
          m2*l1*l2*dq1*sin(q2), 0];

    F = [0.5*dq1;
         0.5*dq2];

    G = [(m1*l1+m2*l1)*g*cos(q1) ...
         + m2*l2*g*cos(q1+q2);
         m2*l2*g*cos(q1+q2)];

    % External disturbance
    d = [0;
         0];

    % Nominal model
    mn1 = 1.7;
    mn2 = 2.0;

    In1 = 0.25*mn1*l1^2;
    In2 = 0.25*mn2*l2^2;

    Mn11 = mn1*l1^2 + mn2*(l1^2+l2^2 ...
        + 2*l1*l2*cos(q2)) + In1 + In2;

    Mn12 = mn2*(l2^2+l1*l2*cos(q2)) + In2;

    Mn22 = mn2*l2^2 + In2;

    Mn = [Mn11 Mn12;
          Mn12 Mn22];

    Cn = [-mn2*l1*l2*dq2*sin(q2), ...
          -mn2*l1*l2*(dq1+dq2)*sin(q2);
           mn2*l1*l2*dq1*sin(q2), 0];

    Fn = [0.5*dq1;
          0.5*dq2];

    Gn = [(mn1*l1+mn2*l1)*g*cos(q1) ...
          + mn2*l2*g*cos(q1+q2);
          mn2*l2*g*cos(q1+q2)];

    % Sliding-mode saturation
    sat_s = min(max(s/phi,-1),1);

    % Nominal control
    tau0 = Mn*(ddqd-Lambda*de) + Cn*dq_meas + Fn + Gn;

    % ASMC
    tau = tau0 - Ks*s - x(5,k)*sat_s;

    % Torque saturation
    tau = min(max(tau,-torque_max),torque_max);

    % True plant
    ddq = M \ (tau-C*dq_true-F-G-d);

    % Adaptive law
    dkhat = gamma*norm(s) - sigma*x(5,k);

    if x(5,k) >= khat_max && dkhat > 0
        dkhat = 0;
    end

    if x(5,k) <= khat_min && dkhat < 0
        dkhat = 0;
    end

    % State update
    x(1:2,k+1) = x(1:2,k) + dt*x(3:4,k);
    x(3:4,k+1) = x(3:4,k) + dt*ddq;
    x(5,k+1) = x(5,k) + dt*dkhat;

    x(5,k+1) = min(max(x(5,k+1),khat_min),khat_max);

end

% Desired trajectory
qd1 = 0.5*sin(t);
qd2 = 0.5*cos(t);

% Error
e1 = x(1,:) - qd1;
e2 = x(2,:) - qd2;

% Metrics
RMSE_q1 = sqrt(mean(e1.^2));
RMSE_q2 = sqrt(mean(e2.^2));

MaxError_q1 = max(abs(e1));
MaxError_q2 = max(abs(e2));

fprintf('Sensor Degradation Scenario\n');
fprintf('Bias q1 = %.3f rad\n',bias(1));
fprintf('Bias q2 = %.3f rad\n',bias(2));
fprintf('Degradation starts at %.1f s\n\n',degradation_time);

fprintf('RMSE q1 = %.6f rad\n',RMSE_q1);
fprintf('RMSE q2 = %.6f rad\n',RMSE_q2);

fprintf('Max Error q1 = %.6f rad\n',MaxError_q1);
fprintf('Max Error q2 = %.6f rad\n',MaxError_q2);

% Plot
figure;

plot(t,x(1,:),'b','LineWidth',1.5);
hold on;
plot(t,qd1,'b--','LineWidth',1.2);

plot(t,x(2,:),'r','LineWidth',1.5);
plot(t,qd2,'r--','LineWidth',1.2);

xline(degradation_time,'k--','Sensor degradation');

xlabel('Time (s)');
ylabel('Joint Position (rad)');

legend('q_1','q_{d1}','q_2','q_{d2}');
grid on;