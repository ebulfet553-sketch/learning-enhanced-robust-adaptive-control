clear;
clc;

dt = 0.001;
T = 10;

t = 0:dt:T;
N = length(t);

x = zeros(5,N);

% Initial condition
x(:,1) = [0; 0.5; 0.5; 0; 1];

% Load disturbance/dynamics RBFNN
load('rbfnn_model_disturbance.mat');

%% Controller parameters

Lambda = diag([6 6]);
Ks = diag([8 8]);

gamma = 0.5;
sigma = 0.5;

phi = 0.05;

khat_min = 0;
khat_max = 30;

torque_max = 20;

%% Simulation

for k = 1:N-1

    %% Desired trajectory

    qd = [0.5*sin(t(k));
          0.5*cos(t(k))];

    dqd = [0.5*cos(t(k));
          -0.5*sin(t(k))];

    ddqd = [-0.5*sin(t(k));
            -0.5*cos(t(k))];

    %% True state

    q = x(1:2,k);
    dq = x(3:4,k);

    %% Tracking error

    e = q - qd;
    de = dq - dqd;

    %% Sliding surface

    s = de + Lambda*e;

    %% Actual robot parameters

    m1 = 1.90;
    m2 = 2.20;

    l1 = 0.41;
    l2 = 0.41;

    I1 = 0.25*m1*l1^2;
    I2 = 0.25*m2*l2^2;

    g = 9.8;

    q1 = q(1);
    q2 = q(2);

    dq1 = dq(1);
    dq2 = dq(2);

    %% Actual dynamics

    M11 = m1*l1^2 + m2*(l1^2+l2^2 ...
        + 2*l1*l2*cos(q2)) + I1 + I2;

    M12 = m2*(l2^2+l1*l2*cos(q2)) + I2;

    M22 = m2*l2^2 + I2;

    M = [M11 M12;
         M12 M22];

    C = [-m2*l1*l2*dq2*sin(q2), ...
         -m2*l1*l2*(dq1+dq2)*sin(q2);
          m2*l1*l2*dq1*sin(q2), 0];

    F = [0.7*dq1;
         0.7*dq2];

    G = [(m1*l1+m2*l1)*g*cos(q1) ...
         + m2*l2*g*cos(q1+q2);
         m2*l2*g*cos(q1+q2)];

    %% External disturbance

    d = [0.8*sin(2*t(k));
         0.5*cos(3*t(k))];

    %% Nominal model

    mn1 = 1.7;
    mn2 = 2.0;

    In1 = 0.25*mn1*l1^2;
    In2 = 0.25*mn2*l2^2;

    Mn11 = mn1*l1^2 + mn2*(l1^2+l2^2 ...
        + 2*l1*l2*cos(q2)) + In1 + In2;

    Mn12 = mn2*(l2^2+l1*l2*cos(q2)) + In2;

    Mn22 = mn2*l2^2 + In2;

    Mn = [Mn11 Mn12;
          Mn12 Mn22];

    Cn = [-mn2*l1*l2*dq2*sin(q2), ...
          -mn2*l1*l2*(dq1+dq2)*sin(q2);
           mn2*l1*l2*dq1*sin(q2), 0];

    Fn = [0.5*dq1;
          0.5*dq2];

    Gn = [(mn1*l1+mn2*l1)*g*cos(q1) ...
          + mn2*l2*g*cos(q1+q2);
          mn2*l2*g*cos(q1+q2)];

    %% RBFNN input

    nn_input = [q;
                dq;
                e;
                de]';

    %% Normalize

    nn_input_n = (nn_input - muX) ./ stdX;

    %% RBF layer

    H = zeros(1,length(centers));

    for j = 1:length(centers)

        distance = norm(nn_input_n - centers(j,:));

        H(j) = exp(-(distance^2)/(2*rbf_sigma^2));

    end

    %% RBFNN uncertainty estimate

    Phi = [H 1];

    Delta_hat_n = Phi * W;

    Delta_hat = Delta_hat_n .* stdY + muY;

    Delta_hat = Delta_hat';

    %% ASMC

    sat_s = min(max(s/phi,-1),1);

    tau0 = Mn*(ddqd-Lambda*de) ...
           + Cn*dq + Fn + Gn;

    tau_asmc = tau0 - Ks*s - x(5,k)*sat_s;

    %% Proposed controller

    tau = tau_asmc - Delta_hat;

    %% Torque saturation

    tau = min(max(tau,-torque_max),torque_max);

    %% Actual plant

    ddq = M \ (tau-C*dq-F-G-d);

    %% Adaptive law

    dkhat = gamma*norm(s) - sigma*x(5,k);

    if x(5,k) >= khat_max && dkhat > 0
        dkhat = 0;
    end

    if x(5,k) <= khat_min && dkhat < 0
        dkhat = 0;
    end

    %% State update

    x(1:2,k+1) = x(1:2,k) + dt*dq;
    x(3:4,k+1) = x(3:4,k) + dt*ddq;
    x(5,k+1) = x(5,k) + dt*dkhat;

    x(5,k+1) = min(max(x(5,k+1),khat_min),khat_max);

end

%% Desired trajectory

qd1 = 0.5*sin(t);
qd2 = 0.5*cos(t);

%% Metrics

e1 = x(1,:) - qd1;
e2 = x(2,:) - qd2;

RMSE_q1 = sqrt(mean(e1.^2));
RMSE_q2 = sqrt(mean(e2.^2));

MaxError_q1 = max(abs(e1));
MaxError_q2 = max(abs(e2));

fprintf('ASMC + RBFNN - Disturbance + Changing Dynamics\n');
fprintf('RMSE q1 = %.6f rad\n',RMSE_q1);
fprintf('RMSE q2 = %.6f rad\n',RMSE_q2);
fprintf('Max Error q1 = %.6f rad\n',MaxError_q1);
fprintf('Max Error q2 = %.6f rad\n',MaxError_q2);

%% Plot

figure;

plot(t,x(1,:),'b','LineWidth',1.5);
hold on;
plot(t,qd1,'b--','LineWidth',1.2);

plot(t,x(2,:),'r','LineWidth',1.5);
plot(t,qd2,'r--','LineWidth',1.2);

xlabel('Time (s)');
ylabel('Joint Position (rad)');

legend('q_1','q_{d1}','q_2','q_{d2}');
grid on;