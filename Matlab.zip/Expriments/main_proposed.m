if ~exist('seed','var')
    seed = 1;
end

rng(seed);

dt = 0.001;
T = 10;

t = 0:dt:T;
N = length(t);

x = zeros(5,N);
tau_history = zeros(2,N-1);

% Initial condition
x(:,1) = [0; 0.5; 0.5; 0; 1];

%% Load trained RBFNN
load('rbfnn_model_networked.mat');

%% Uncertainty conditions

% Sensor noise
sigma_q = 0.01;
sigma_dq = 0.02;

q_noise = sigma_q * randn(2,N);
dq_noise = sigma_dq * randn(2,N);

% Sensor degradation
degradation_time = 5;

bias = [0.05;
       -0.05];

% Communication delay
delay = 0.10;
delay_steps = round(delay/dt);

% Packet loss
p_loss = 0.10;

%% Controller parameters

Lambda = diag([6 6]);
Ks = diag([8 8]);

gamma = 0.5;
sigma = 0.5;

phi = 0.05;

khat_min = 0;
khat_max = 30;

torque_max = 20;

%% Last received measurement

q_received = x(1:2,1);
dq_received = x(3:4,1);

%% Simulation

for k = 1:N-1

    %% Delayed sensor measurement

    kd = max(1,k-delay_steps);

    q_packet = x(1:2,kd) + q_noise(:,kd);
    dq_packet = x(3:4,kd) + dq_noise(:,kd);

    %% Sensor degradation

    if t(k) >= degradation_time
        q_packet = q_packet + bias;
    end

    %% Packet loss

    packet_lost = rand < p_loss;

    if ~packet_lost
        q_received = q_packet;
        dq_received = dq_packet;
    end

    %% Desired trajectory

    qd = [0.5*sin(t(k));
          0.5*cos(t(k))];

    dqd = [0.5*cos(t(k));
          -0.5*sin(t(k))];

    ddqd = [-0.5*sin(t(k));
            -0.5*cos(t(k))];

    %% Tracking errors

    e = q_received - qd;
    de = dq_received - dqd;

    %% Sliding surface

    s = de + Lambda*e;

    %% Robot parameters

    m1 = 1.90;
    m2 = 2.20;

    l1 = 0.41;
    l2 = 0.41;

    I1 = 0.25*m1*l1^2;
    I2 = 0.25*m2*l2^2;

    g = 9.8;

    q1 = x(1,k);
    q2 = x(2,k);

    dq1 = x(3,k);
    dq2 = x(4,k);

    %% Actual dynamics

    M11 = m1*l1^2 + m2*(l1^2+l2^2 ...
        + 2*l1*l2*cos(q2)) + I1 + I2;

    M12 = m2*(l2^2+l1*l2*cos(q2)) + I2;

    M22 = m2*l2^2 + I2;

    M = [M11 M12;
         M12 M22];

    C = [-m2*l1*l2*dq2*sin(q2), ...
         -m2*l1*l2*(dq1+dq2)*sin(q2);
          m2*l1*l2*dq1*sin(q2), 0];

    F = [0.7*dq1;
         0.7*dq2];

    G = [(m1*l1+m2*l1)*g*cos(q1) ...
         + m2*l2*g*cos(q1+q2);
         m2*l2*g*cos(q1+q2)];

    % External disturbance
    d = [0.8*sin(2*t(k));
         0.5*cos(3*t(k))];

    %% Nominal dynamics

    mn1 = 1.7;
    mn2 = 2.0;

    In1 = 0.25*mn1*l1^2;
    In2 = 0.25*mn2*l2^2;

    Mn11 = mn1*l1^2 + mn2*(l1^2+l2^2 ...
        + 2*l1*l2*cos(q2)) + In1 + In2;

    Mn12 = mn2*(l2^2+l1*l2*cos(q2)) + In2;

    Mn22 = mn2*l2^2 + In2;

    Mn = [Mn11 Mn12;
          Mn12 Mn22];

    Cn = [-mn2*l1*l2*dq2*sin(q2), ...
          -mn2*l1*l2*(dq1+dq2)*sin(q2);
           mn2*l1*l2*dq1*sin(q2), 0];

    Fn = [0.5*dq1;
          0.5*dq2];

    Gn = [(mn1*l1+mn2*l1)*g*cos(q1) ...
          + mn2*l2*g*cos(q1+q2);
          mn2*l2*g*cos(q1+q2)];

    %% RBFNN input

    nn_input = [q_received;
                dq_received;
                e;
                de;
                delay;
                double(packet_lost)]';

    %% Normalize input

    nn_input_n = (nn_input - muX) ./ stdX;

    %% RBF layer

    H = zeros(1,length(centers));

    for j = 1:length(centers)

        distance = norm(nn_input_n - centers(j,:));

        H(j) = exp(-(distance^2)/(2*rbf_sigma^2));

    end

    %% RBFNN uncertainty estimate

    Phi = [H 1];

    Delta_hat_n = Phi * W;

    Delta_hat = Delta_hat_n .* stdY + muY;

    Delta_hat = Delta_hat';

    %% Robust adaptive controller

    sat_s = min(max(s/phi,-1),1);

    tau0 = Mn*(ddqd-Lambda*de) ...
           + Cn*dq_received ...
           + Fn + Gn;

    tau_asmc = tau0 - Ks*s - x(5,k)*sat_s;

    %% Proposed controller

    tau = tau_asmc - Delta_hat;

    %% Torque saturation

    tau = min(max(tau,-torque_max),torque_max);

    %% Store control input

    tau_history(:,k) = tau;

    %% True plant

    ddq = M \ (tau-C*[dq1;dq2]-F-G-d);

    %% Adaptive law

    dkhat = gamma*norm(s) - sigma*x(5,k);

    if x(5,k) >= khat_max && dkhat > 0
        dkhat = 0;
    end

    if x(5,k) <= khat_min && dkhat < 0
        dkhat = 0;
    end

    %% State update

    x(1:2,k+1) = x(1:2,k) + dt*x(3:4,k);
    x(3:4,k+1) = x(3:4,k) + dt*ddq;
    x(5,k+1) = x(5,k) + dt*dkhat;

    x(5,k+1) = min(max(x(5,k+1),khat_min),khat_max);

end

%% Desired trajectory

qd1 = 0.5*sin(t);
qd2 = 0.5*cos(t);

%% Tracking errors

e1 = x(1,:) - qd1;
e2 = x(2,:) - qd2;

%% Metrics

RMSE_q1 = sqrt(mean(e1.^2));
RMSE_q2 = sqrt(mean(e2.^2));

MaxError_q1 = max(abs(e1));
MaxError_q2 = max(abs(e2));

%% Control effort

ControlEffort = trapz(t(1:end-1), ...
    sqrt(sum(tau_history.^2,1)));

%% Results

fprintf('ASMC + RBFNN - Combined Uncertainty + Sensor Degradation\n');
fprintf('Sensor noise = %.3f / %.3f\n',sigma_q,sigma_dq);
fprintf('Sensor degradation starts = %.1f s\n',degradation_time);
fprintf('Sensor bias = %.3f / %.3f rad\n',bias(1),bias(2));
fprintf('Delay = %.0f ms\n',delay*1000);
fprintf('Packet loss = %.0f %%\n\n',p_loss*100);

fprintf('RMSE q1 = %.6f rad\n',RMSE_q1);
fprintf('RMSE q2 = %.6f rad\n',RMSE_q2);

fprintf('Max Error q1 = %.6f rad\n',MaxError_q1);
fprintf('Max Error q2 = %.6f rad\n',MaxError_q2);

fprintf('Control Effort = %.6f N.m.s\n',ControlEffort);

%% Tracking plot

figure;

plot(t,x(1,:),'b','LineWidth',1.5);
hold on;

plot(t,qd1,'b--','LineWidth',1.2);

plot(t,x(2,:),'r','LineWidth',1.5);
plot(t,qd2,'r--','LineWidth',1.2);

xline(degradation_time,'k--','Sensor degradation');

xlabel('Time (s)');
ylabel('Joint Position (rad)');

legend('q_1','q_{d1}','q_2','q_{d2}');

grid on;