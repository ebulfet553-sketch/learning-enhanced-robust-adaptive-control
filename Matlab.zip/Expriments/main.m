clear;
clc;

rng(1);

x0 = [0; 0.5; 0.5; 0; 1];

tspan = [0 10];

% Sensor noise
noise_t = 0:0.001:10;

sigma_q = 0.01;
sigma_dq = 0.02;

q_noise = sigma_q * randn(2,length(noise_t));
dq_noise = sigma_dq * randn(2,length(noise_t));

% Simulation
[t,x] = ode45(@(t,x) robot2dof(t,x,noise_t,q_noise,dq_noise), ...
              tspan,x0);

% Desired trajectory
qd1 = 0.5*sin(t);
qd2 = 0.5*cos(t);

% Plot
figure;

plot(t,x(:,1),'b','LineWidth',1.5);
hold on;
plot(t,qd1,'b--','LineWidth',1.2);

plot(t,x(:,2),'r','LineWidth',1.5);
plot(t,qd2,'r--','LineWidth',1.2);

xlabel('Time (s)');
ylabel('Joint Position (rad)');
legend('q_1','q_{d1}','q_2','q_{d2}');
grid on;

e1 = x(:,1) - qd1;
e2 = x(:,2) - qd2;

RMSE_q1 = sqrt(mean(e1.^2));
RMSE_q2 = sqrt(mean(e2.^2));

MaxError_q1 = max(abs(e1));
MaxError_q2 = max(abs(e2));

fprintf('Sensor Noise Scenario\n');
fprintf('RMSE q1 = %.6f rad\n', RMSE_q1);
fprintf('RMSE q2 = %.6f rad\n', RMSE_q2);
fprintf('Max Error q1 = %.6f rad\n', MaxError_q1);
fprintf('Max Error q2 = %.6f rad\n', MaxError_q2);

% Tracking error plot
figure;

plot(t,e1,'b','LineWidth',1.5);
hold on;
plot(t,e2,'r','LineWidth',1.5);

xlabel('Time (s)');
ylabel('Tracking Error (rad)');
legend('e_1','e_2');
grid on;6.1 