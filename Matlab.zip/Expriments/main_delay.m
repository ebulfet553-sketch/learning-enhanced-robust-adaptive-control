clear;
clc;

dt = 0.001;
T = 10;
t = 0:dt:T;
N = length(t);

x = zeros(5,N);

% Initial condition
x(:,1) = [0; 0.5; 0.5; 0; 1];

% Communication delay
delay = 0.10;
delay_steps = round(delay/dt);

% Controller parameters
Lambda = diag([6 6]);
Ks = diag([8 8]);

gamma = 0.5;
sigma = 0.5;

khat_min = 0;
khat_max = 30;

torque_max = 20;

for k = 1:N-1

    % Delayed measurement
    kd = max(1,k-delay_steps);

    q_meas = x(1:2,kd);
    dq_meas = x(3:4,kd);

    % Desired trajectory
    qd = [0.5*sin(t(k));
          0.5*cos(t(k))];

    dqd = [0.5*cos(t(k));
          -0.5*sin(t(k))];

    ddqd = [-0.5*sin(t(k));
            -0.5*cos(t(k))];

    % Tracking error
    e = q_meas - qd;
    de = dq_meas - dqd;

    % Sliding surface
    s = de + Lambda*e;

    % Robot parameters
    m1 = 1.7;
    m2 = 2.0;

    l1 = 0.41;
    l2 = 0.41;

    I1 = 0.25*m1*l1^2;
    I2 = 0.25*m2*l2^2;

    g = 9.8;

    % Current true state
    q1 = x(1,k);
    q2 = x(2,k);

    dq1 = x(3,k);
    dq2 = x(4,k);

    % Inertia matrix
    M11 = m1*l1^2 + m2*(l1^2+l2^2 ...
        + 2*l1*l2*cos(q2)) + I1 + I2;

    M12 = m2*(l2^2+l1*l2*cos(q2)) + I2;

    M22 = m2*l2^2 + I2;

    M = [M11 M12;
         M12 M22];

    % Coriolis matrix
    C = [-m2*l1*l2*dq2*sin(q2), ...
         -m2*l1*l2*(dq1+dq2)*sin(q2);
          m2*l1*l2*dq1*sin(q2), 0];

    % Friction
    F = [0.5*dq1;
         0.5*dq2];

    % Gravity
    G = [(m1*l1+m2*l1)*g*cos(q1) ...
         + m2*l2*g*cos(q1+q2);
         m2*l2*g*cos(q1+q2)];

    % Saturation function
    phi = 0.05;
    sat_s = min(max(s/phi,-1),1);

    % Nominal control
    tau0 = M*(ddqd-Lambda*de) + C*dq_meas + F + G;

    % Adaptive sliding-mode control
    tau = tau0 - Ks*s - x(5,k)*sat_s;

    % Torque saturation
    tau = min(max(tau,-torque_max),torque_max);

    % True plant dynamics
    ddq = M \ (tau - C*[dq1;dq2] - F - G);

    % Adaptive gain with leakage
    dkhat = gamma*norm(s) - sigma*x(5,k);

    % Adaptive gain limits
    if x(5,k) >= khat_max && dkhat > 0
        dkhat = 0;
    end

    if x(5,k) <= khat_min && dkhat < 0
        dkhat = 0;
    end

    % Euler integration
    x(1:2,k+1) = x(1:2,k) + dt*x(3:4,k);
    x(3:4,k+1) = x(3:4,k) + dt*ddq;
    x(5,k+1) = x(5,k) + dt*dkhat;

    % Enforce adaptive gain bounds
    x(5,k+1) = min(max(x(5,k+1),khat_min),khat_max);
end

% Desired trajectory
qd1 = 0.5*sin(t);
qd2 = 0.5*cos(t);

% Tracking error
e1 = x(1,:) - qd1;
e2 = x(2,:) - qd2;

% Metrics
RMSE_q1 = sqrt(mean(e1.^2));
RMSE_q2 = sqrt(mean(e2.^2));

MaxError_q1 = max(abs(e1));
MaxError_q2 = max(abs(e2));

fprintf('100 ms Communication Delay\n');
fprintf('RMSE q1 = %.6f rad\n',RMSE_q1);
fprintf('RMSE q2 = %.6f rad\n',RMSE_q2);
fprintf('Max Error q1 = %.6f rad\n',MaxError_q1);
fprintf('Max Error q2 = %.6f rad\n',MaxError_q2);

% Tracking plot
figure;

plot(t,x(1,:),'b','LineWidth',1.5);
hold on;
plot(t,qd1,'b--','LineWidth',1.2);

plot(t,x(2,:),'r','LineWidth',1.5);
plot(t,qd2,'r--','LineWidth',1.2);

xlabel('Time (s)');
ylabel('Joint Position (rad)');

legend('q_1','q_{d1}','q_2','q_{d2}');
grid on;