clear;
clc;

rng(1);

dt = 0.001;
T = 10;

t = 0:dt:T;
N = length(t);

x = zeros(5,N);

% Initial condition
x(:,1) = [0; 0.5; 0.5; 0; 1];

% Packet loss probability
p_loss = 0.10;      % 10%

% Controller parameters
Lambda = diag([10 10]);
Ks = diag([25 25]);

gamma = 2;
phi = 0.01;

% Last successfully received measurement
q_received = x(1:2,1);
dq_received = x(3:4,1);

for k = 1:N-1

    % Packet transmission
    if rand > p_loss
        q_received = x(1:2,k);
        dq_received = x(3:4,k);
    end

    % Desired trajectory
    qd = [0.5*sin(t(k));
          0.5*cos(t(k))];

    dqd = [0.5*cos(t(k));
          -0.5*sin(t(k))];

    ddqd = [-0.5*sin(t(k));
            -0.5*cos(t(k))];

    % Tracking error based on received measurement
    e = q_received - qd;
    de = dq_received - dqd;

    % Sliding surface
    s = de + Lambda*e;

    % Robot parameters
    m1 = 1.7;
    m2 = 2.0;

    l1 = 0.41;
    l2 = 0.41;

    I1 = 0.25*m1*l1^2;
    I2 = 0.25*m2*l2^2;

    g = 9.8;

    % True state
    q1 = x(1,k);
    q2 = x(2,k);

    dq1 = x(3,k);
    dq2 = x(4,k);

    % Inertia matrix
    M11 = m1*l1^2 + m2*(l1^2+l2^2 ...
        + 2*l1*l2*cos(q2)) + I1 + I2;

    M12 = m2*(l2^2+l1*l2*cos(q2)) + I2;

    M22 = m2*l2^2 + I2;

    M = [M11 M12;
         M12 M22];

    % Coriolis matrix
    C = [-m2*l1*l2*dq2*sin(q2), ...
         -m2*l1*l2*(dq1+dq2)*sin(q2);
          m2*l1*l2*dq1*sin(q2), 0];

    % Friction
    F = [0.5*dq1;
         0.5*dq2];

    % Gravity
    G = [(m1*l1+m2*l1)*g*cos(q1) ...
         + m2*l2*g*cos(q1+q2);
         m2*l2*g*cos(q1+q2)];

    % Saturation function
    sat_s = min(max(s/phi,-1),1);

    % Nominal control
    tau0 = M*(ddqd-Lambda*de) + C*dq_received + F + G;

    % ASMC
    tau = tau0 - Ks*s - x(5,k)*sat_s;

    % Torque limit
    tau = min(max(tau,-20),20);

    % True plant dynamics
    ddq = M \ (tau-C*[dq1;dq2]-F-G);

    % Adaptive gain
    dkhat = gamma*norm(s);

    % State update
    x(1:2,k+1) = x(1:2,k) + dt*x(3:4,k);
    x(3:4,k+1) = x(3:4,k) + dt*ddq;
    x(5,k+1) = x(5,k) + dt*dkhat;

    % Limit adaptive gain
    x(5,k+1) = min(x(5,k+1),30);
end

% Desired trajectory
qd1 = 0.5*sin(t);
qd2 = 0.5*cos(t);

% Tracking error
e1 = x(1,:) - qd1;
e2 = x(2,:) - qd2;

% Metrics
RMSE_q1 = sqrt(mean(e1.^2));
RMSE_q2 = sqrt(mean(e2.^2));

MaxError_q1 = max(abs(e1));
MaxError_q2 = max(abs(e2));

fprintf('10%% Packet Loss\n');
fprintf('RMSE q1 = %.6f rad\n',RMSE_q1);
fprintf('RMSE q2 = %.6f rad\n',RMSE_q2);

fprintf('Max Error q1 = %.6f rad\n',MaxError_q1);
fprintf('Max Error q2 = %.6f rad\n',MaxError_q2);

% Plot
figure;

plot(t,x(1,:),'b','LineWidth',1.5);
hold on;
plot(t,qd1,'b--','LineWidth',1.2);

plot(t,x(2,:),'r','LineWidth',1.5);
plot(t,qd2,'r--','LineWidth',1.2);

xlabel('Time (s)');
ylabel('Joint Position (rad)');

legend('q_1','q_{d1}','q_2','q_{d2}');
grid on;