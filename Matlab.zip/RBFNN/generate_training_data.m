clear;
clc;

rng(1);

dt = 0.001;
T = 20;

t = 0:dt:T;
N = length(t);

x = zeros(4,N);

% Initial condition
x(:,1) = [0; 0.5; 0.5; 0];

% Communication conditions
delay = 0.10;          % 100 ms
delay_steps = round(delay/dt);

p_loss = 0.10;         % 10% packet loss

% Sensor noise
sigma_q = 0.01;
sigma_dq = 0.02;

q_noise = sigma_q*randn(2,N);
dq_noise = sigma_dq*randn(2,N);

% Sensor degradation
degradation_time = 5;     % degradation starts at 5 s

bias = [0.05;
       -0.05];

% Storage
X = zeros(10,N-1);
Y = zeros(2,N-1);

% Last received measurement
q_received = x(1:2,1);
dq_received = x(3:4,1);

for k = 1:N-1

    % Delayed sensor measurement
    kd = max(1,k-delay_steps);

    q_packet = x(1:2,kd) + q_noise(:,kd);
    dq_packet = x(3:4,kd) + dq_noise(:,kd);

    % Sensor degradation
    if t(k) >= degradation_time
        q_packet = q_packet + bias;
    end

    % Packet loss
    packet_lost = rand < p_loss;

    if ~packet_lost
        q_received = q_packet;
        dq_received = dq_packet;
    end

    % Desired trajectory
    qd = [0.5*sin(t(k));
          0.5*cos(t(k))];

    dqd = [0.5*cos(t(k));
          -0.5*sin(t(k))];

    ddqd = [-0.5*sin(t(k));
            -0.5*cos(t(k))];

    % Tracking error
    e = q_received - qd;
    de = dq_received - dqd;

    % Sliding surface
    Lambda = diag([6 6]);
    s = de + Lambda*e;

    % Actual robot parameters
    m1 = 1.90;
    m2 = 2.20;

    l1 = 0.41;
    l2 = 0.41;

    I1 = 0.25*m1*l1^2;
    I2 = 0.25*m2*l2^2;

    g = 9.8;

    q1 = x(1,k);
    q2 = x(2,k);

    dq1 = x(3,k);
    dq2 = x(4,k);

    % Actual inertia matrix
    M11 = m1*l1^2 + m2*(l1^2+l2^2+ ...
        2*l1*l2*cos(q2)) + I1 + I2;

    M12 = m2*(l2^2+l1*l2*cos(q2)) + I2;

    M22 = m2*l2^2 + I2;

    M = [M11 M12;
         M12 M22];

    % Actual Coriolis matrix
    C = [-m2*l1*l2*dq2*sin(q2), ...
         -m2*l1*l2*(dq1+dq2)*sin(q2);
          m2*l1*l2*dq1*sin(q2), 0];

    % Actual friction
    F = [0.7*dq1;
         0.7*dq2];

    % Actual gravity
    G = [(m1*l1+m2*l1)*g*cos(q1) ...
         + m2*l2*g*cos(q1+q2);
         m2*l2*g*cos(q1+q2)];

    % External disturbance
    d = [0.8*sin(2*t(k));
         0.5*cos(3*t(k))];

    % Nominal model parameters
    mn1 = 1.7;
    mn2 = 2.0;

    In1 = 0.25*mn1*l1^2;
    In2 = 0.25*mn2*l2^2;

    Mn11 = mn1*l1^2 + mn2*(l1^2+l2^2+ ...
        2*l1*l2*cos(q2)) + In1 + In2;

    Mn12 = mn2*(l2^2+l1*l2*cos(q2)) + In2;

    Mn22 = mn2*l2^2 + In2;

    Mn = [Mn11 Mn12;
          Mn12 Mn22];

    Cn = [-mn2*l1*l2*dq2*sin(q2), ...
          -mn2*l1*l2*(dq1+dq2)*sin(q2);
           mn2*l1*l2*dq1*sin(q2), 0];

    Fn = [0.5*dq1;
          0.5*dq2];

    Gn = [(mn1*l1+mn2*l1)*g*cos(q1) ...
          + mn2*l2*g*cos(q1+q2);
          mn2*l2*g*cos(q1+q2)];

    % Nominal control
    phi = 0.05;
    Ks = diag([8 8]);

    sat_s = min(max(s/phi,-1),1);

    tau0 = Mn*(ddqd-Lambda*de) + Cn*dq_received + Fn + Gn;

    % Robust baseline controller used for data generation
    tau = tau0 - Ks*s;

    % Torque saturation
    tau = min(max(tau,-20),20);

    % Actual robot dynamics
    ddq = M \ (tau-C*[dq1;dq2]-F-G-d);

    % Lumped uncertainty target
    Delta = Mn*ddq + Cn*[dq1;dq2] + Fn + Gn - tau;

    % RBFNN input
    X(:,k) = [q_received;
              dq_received;
              e;
              de;
              delay;
              double(packet_lost)];

    % RBFNN target
    Y(:,k) = Delta;

    % Plant update
    x(1:2,k+1) = x(1:2,k) + dt*x(3:4,k);
    x(3:4,k+1) = x(3:4,k) + dt*ddq;

end

save('rbfnn_training_data_networked.mat','X','Y');

fprintf('Networked RBFNN training data generated.\n');
fprintf('Samples: %d\n',size(X,2));
fprintf('Input dimension: %d\n',size(X,1));
fprintf('Output dimension: %d\n',size(Y,1));