clear;
clc;

rng(1);

dt = 0.001;
T = 20;

t = 0:dt:T;
N = length(t);

x = zeros(4,N);
x(:,1) = [0; 0.5; 0.5; 0];

% No communication uncertainty
delay = 0;
packet_lost = 0;

% Storage
X = zeros(8,N-1);
Y = zeros(2,N-1);

for k = 1:N-1

    q = x(1:2,k);
    dq = x(3:4,k);

    qd = [0.5*sin(t(k));
          0.5*cos(t(k))];

    dqd = [0.5*cos(t(k));
          -0.5*sin(t(k))];

    ddqd = [-0.5*sin(t(k));
            -0.5*cos(t(k))];

    e = q - qd;
    de = dq - dqd;

    Lambda = diag([6 6]);
    s = de + Lambda*e;

    % Actual robot: changed parameters
    m1 = 1.90;
    m2 = 2.20;

    l1 = 0.41;
    l2 = 0.41;

    I1 = 0.25*m1*l1^2;
    I2 = 0.25*m2*l2^2;

    g = 9.8;

    q1 = q(1);
    q2 = q(2);

    dq1 = dq(1);
    dq2 = dq(2);

    M11 = m1*l1^2 + m2*(l1^2+l2^2 ...
        + 2*l1*l2*cos(q2)) + I1 + I2;

    M12 = m2*(l2^2+l1*l2*cos(q2)) + I2;

    M22 = m2*l2^2 + I2;

    M = [M11 M12;
         M12 M22];

    C = [-m2*l1*l2*dq2*sin(q2), ...
         -m2*l1*l2*(dq1+dq2)*sin(q2);
          m2*l1*l2*dq1*sin(q2), 0];

    F = [0.7*dq1;
         0.7*dq2];

    G = [(m1*l1+m2*l1)*g*cos(q1) ...
         + m2*l2*g*cos(q1+q2);
         m2*l2*g*cos(q1+q2)];

    % External disturbance
    d = [0.8*sin(2*t(k));
         0.5*cos(3*t(k))];

    % Nominal model
    mn1 = 1.7;
    mn2 = 2.0;

    In1 = 0.25*mn1*l1^2;
    In2 = 0.25*mn2*l2^2;

    Mn11 = mn1*l1^2 + mn2*(l1^2+l2^2 ...
        + 2*l1*l2*cos(q2)) + In1 + In2;

    Mn12 = mn2*(l2^2+l1*l2*cos(q2)) + In2;

    Mn22 = mn2*l2^2 + In2;

    Mn = [Mn11 Mn12;
          Mn12 Mn22];

    Cn = [-mn2*l1*l2*dq2*sin(q2), ...
          -mn2*l1*l2*(dq1+dq2)*sin(q2);
           mn2*l1*l2*dq1*sin(q2), 0];

    Fn = [0.5*dq1;
          0.5*dq2];

    Gn = [(mn1*l1+mn2*l1)*g*cos(q1) ...
          + mn2*l2*g*cos(q1+q2);
          mn2*l2*g*cos(q1+q2)];

    % Baseline control used for generating training data
    sat_s = min(max(s/0.05,-1),1);

    tau0 = Mn*(ddqd-Lambda*de) + Cn*dq + Fn + Gn;

    tau = tau0 - diag([8 8])*s;

    tau = min(max(tau,-20),20);

    % Actual plant
    ddq = M \ (tau-C*dq-F-G-d);

    % Lumped uncertainty
    Delta = Mn*ddq + Cn*dq + Fn + Gn - tau;

    % RBFNN input
    X(:,k) = [q;
              dq;
              e;
              de];

    Y(:,k) = Delta;

    % Update
    x(1:2,k+1) = x(1:2,k) + dt*dq;
    x(3:4,k+1) = x(3:4,k) + dt*ddq;
end

save('rbfnn_training_data_disturbance.mat','X','Y');

fprintf('Disturbance/dynamics training data generated.\n');
fprintf('Samples: %d\n',size(X,2));
fprintf('Input dimension: %d\n',size(X,1));
fprintf('Output dimension: %d\n',size(Y,1));