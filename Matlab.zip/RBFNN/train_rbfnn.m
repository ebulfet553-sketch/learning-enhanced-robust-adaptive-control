clear;
clc;

%% Load training data
load('rbfnn_training_data_networked.mat');
% X: inputs
% Y: uncertainty targets

%% Train / validation split

rng(1);

N = size(X,2);

idx = randperm(N);

Ntrain = round(0.8*N);

train_idx = idx(1:Ntrain);
val_idx   = idx(Ntrain+1:end);

Xtrain = X(:,train_idx)';
Ytrain = Y(:,train_idx)';

Xval = X(:,val_idx)';
Yval = Y(:,val_idx)';

%% Normalize inputs and outputs

muX = mean(Xtrain,1);
stdX = std(Xtrain,0,1);

muY = mean(Ytrain,1);
stdY = std(Ytrain,0,1);

stdX(stdX < 1e-8) = 1;
stdY(stdY < 1e-8) = 1;

Xtrain_n = (Xtrain - muX)./stdX;
Ytrain_n = (Ytrain - muY)./stdY;

Xval_n = (Xval - muX)./stdX;
Yval_n = (Yval - muY)./stdY;

%% RBF network parameters

numCenters = 40;

% Select centers from training samples
center_idx = randperm(size(Xtrain_n,1),numCenters);

centers = Xtrain_n(center_idx,:);

%% Calculate RBF width

distances = zeros(numCenters,numCenters);

for i = 1:numCenters
    for j = 1:numCenters
        distances(i,j) = norm(centers(i,:) - centers(j,:));
    end
end

distances = distances(distances > 0);

rbf_sigma = mean(distances);

if rbf_sigma <= 0
    rbf_sigma = 1;
end

%% Training RBF layer

Htrain = zeros(size(Xtrain_n,1),numCenters);

for n = 1:size(Xtrain_n,1)

    for j = 1:numCenters

        distance = norm(Xtrain_n(n,:) - centers(j,:));

        Htrain(n,j) = exp(-(distance^2)/(2*rbf_sigma^2));

    end

end

% Add bias
Phi_train = [Htrain ones(size(Htrain,1),1)];

%% Ridge regression for output weights

lambda = 1e-6;

W = (Phi_train' * Phi_train + ...
     lambda*eye(size(Phi_train,2))) \ ...
     (Phi_train' * Ytrain_n);

%% Validation

Hval = zeros(size(Xval_n,1),numCenters);

for n = 1:size(Xval_n,1)

    for j = 1:numCenters

        distance = norm(Xval_n(n,:) - centers(j,:));

        Hval(n,j) = exp(-(distance^2)/(2*rbf_sigma^2));

    end

end

Phi_val = [Hval ones(size(Hval,1),1)];

Ypred_n = Phi_val * W;

% Convert back to original units
Ypred = Ypred_n .* stdY + muY;

%% Validation metrics

error = Yval - Ypred;

RMSE1 = sqrt(mean(error(:,1).^2));
RMSE2 = sqrt(mean(error(:,2).^2));

fprintf('RBFNN Validation Results\n');
fprintf('RMSE uncertainty 1 = %.6f\n',RMSE1);
fprintf('RMSE uncertainty 2 = %.6f\n',RMSE2);

%% Save trained model

save('rbfnn_model_networked.mat', ...
    'centers', ...
    'rbf_sigma', ...
    'W', ...
    'muX', ...
    'stdX', ...
    'muY', ...
    'stdY');

fprintf('RBFNN model saved as rbfnn_model.mat\n');