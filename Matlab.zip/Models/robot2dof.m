function xdot = robot2dof(t,x,noise_t,q_noise,dq_noise)

% Robot parameters
m1 = 1.7;
m2 = 2.0;

l1 = 0.41;
l2 = 0.41;

I1 = 0.25*m1*l1^2;
I2 = 0.25*m2*l2^2;

g = 9.8;

% True states
q_true = x(1:2);
dq_true = x(3:4);

% Measured states
q_meas = q_true + [
    interp1(noise_t,q_noise(1,:),t,'linear','extrap');
    interp1(noise_t,q_noise(2,:),t,'linear','extrap')
];

dq_meas = dq_true + [
    interp1(noise_t,dq_noise(1,:),t,'linear','extrap');
    interp1(noise_t,dq_noise(2,:),t,'linear','extrap')
];

% Adaptive gain
khat = x(5);

% Desired trajectory
qd = [0.5*sin(t);
      0.5*cos(t)];

dqd = [0.5*cos(t);
       -0.5*sin(t)];

ddqd = [-0.5*sin(t);
        -0.5*cos(t)];

% Tracking error from measured states
e = q_meas - qd;
de = dq_meas - dqd;

% Sliding surface
Lambda = diag([10 10]);
s = de + Lambda*e;

% True robot dynamics
q1 = q_true(1);
q2 = q_true(2);

dq1 = dq_true(1);
dq2 = dq_true(2);

M11 = m1*l1^2 + m2*(l1^2 + l2^2 + ...
      2*l1*l2*cos(q2)) + I1 + I2;

M12 = m2*(l2^2 + l1*l2*cos(q2)) + I2;

M22 = m2*l2^2 + I2;

M = [M11 M12;
     M12 M22];

C = [-m2*l1*l2*dq2*sin(q2), ...
     -m2*l1*l2*(dq1+dq2)*sin(q2);
      m2*l1*l2*dq1*sin(q2), 0];

F = [0.5*dq1;
     0.5*dq2];

G = [(m1*l1+m2*l1)*g*cos(q1) + ...
     m2*l2*g*cos(q1+q2);
     m2*l2*g*cos(q1+q2)];

% ASMC parameters
Ks = diag([25 25]);
gamma = 2;
phi = 0.01;

% Saturation
sat_s = min(max(s/phi,-1),1);

% Nominal control
tau0 = M*(ddqd - Lambda*de) + C*dq_true + F + G;

% ASMC
tau = tau0 - Ks*s - khat*sat_s;

% True plant dynamics
ddq = M \ (tau - C*dq_true - F - G);

% Adaptive law
dkhat = gamma*norm(s);

% State derivative
xdot = [dq_true;
        ddq;
        dkhat];

end