function xdot = robot2dof_uncertain(t,x,tau)

% Actual robot parameters
m1 = 1.90;
m2 = 2.20;

l1 = 0.41;
l2 = 0.41;

I1 = 0.25*m1*l1^2;
I2 = 0.25*m2*l2^2;

g = 9.8;

% States
q = x(1:2);
dq = x(3:4);

q1 = q(1);
q2 = q(2);

dq1 = dq(1);
dq2 = dq(2);

% Actual inertia matrix
M11 = m1*l1^2 + m2*(l1^2 + l2^2 + ...
    2*l1*l2*cos(q2)) + I1 + I2;

M12 = m2*(l2^2 + l1*l2*cos(q2)) + I2;

M22 = m2*l2^2 + I2;

M = [M11 M12;
    M12 M22];

% Actual Coriolis matrix
C = [-m2*l1*l2*dq2*sin(q2), ...
    -m2*l1*l2*(dq1+dq2)*sin(q2);
    m2*l1*l2*dq1*sin(q2), 0];

% Actual friction
F = [0.7*dq1;
    0.7*dq2];

% Actual gravity
G = [(m1*l1+m2*l1)*g*cos(q1) ...
    + m2*l2*g*cos(q1+q2);
    m2*l2*g*cos(q1+q2)];

% External disturbance
d = [0.8*sin(2*t);
    0.5*cos(3*t)];

% Actual plant dynamics
ddq = M \ (tau - C*dq - F - G - d);

% State derivative
xdot = [dq;
    ddq];

end