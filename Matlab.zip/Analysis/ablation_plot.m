clear;
clc;

scenarios = categorical({
    'Combined'
    'Combined + Sensor Degradation'
    'Disturbance + Dynamics'
    });

% q1 RMSE
ASMC_q1 = [0.933173 0.904095 0.798392];
RBFNN_q1 = [0.883266 0.906200 0.798705];

% q2 RMSE
ASMC_q2 = [1.041890 0.829856 0.039690];
RBFNN_q2 = [0.852563 0.837462 0.046209];

%% q1

figure;

bar(scenarios,[ASMC_q1' RBFNN_q1']);

ylabel('RMSE (rad)');
legend('ASMC','ASMC + RBFNN','Location','best');
title('Ablation Study: Joint 1 Tracking Error');
grid on;

%% q2

figure;

bar(scenarios,[ASMC_q2' RBFNN_q2']);

ylabel('RMSE (rad)');
legend('ASMC','ASMC + RBFNN','Location','best');
title('Ablation Study: Joint 2 Tracking Error');
grid on;