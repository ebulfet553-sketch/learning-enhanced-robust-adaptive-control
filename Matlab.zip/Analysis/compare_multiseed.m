clear;
clc;
close all;

numSeeds = 10;

ASMC_RMSE = zeros(numSeeds,2);
RBFNN_RMSE = zeros(numSeeds,2);

ASMC_Effort = zeros(numSeeds,1);
RBFNN_Effort = zeros(numSeeds,1);

for seed = 1:numSeeds

    fprintf('\nSeed %d\n',seed);

    % ASMC
    run('main_combined.m');

    ASMC_RMSE(seed,1) = RMSE_q1;
    ASMC_RMSE(seed,2) = RMSE_q2;
    ASMC_Effort(seed) = ControlEffort;

    close all;

    % ASMC + RBFNN
    run('main_proposed.m');

    RBFNN_RMSE(seed,1) = RMSE_q1;
    RBFNN_RMSE(seed,2) = RMSE_q2;
    RBFNN_Effort(seed) = ControlEffort;

    close all;

end

% Mean
mean_ASMC = mean(ASMC_RMSE,1);
mean_RBFNN = mean(RBFNN_RMSE,1);

% Standard deviation
std_ASMC = std(ASMC_RMSE,0,1);
std_RBFNN = std(RBFNN_RMSE,0,1);

% Control effort
mean_effort_ASMC = mean(ASMC_Effort);
mean_effort_RBFNN = mean(RBFNN_Effort);

std_effort_ASMC = std(ASMC_Effort);
std_effort_RBFNN = std(RBFNN_Effort);

% RMSE improvement
improvement_q1 = ...
    100*(mean_ASMC(1)-mean_RBFNN(1))/mean_ASMC(1);

improvement_q2 = ...
    100*(mean_ASMC(2)-mean_RBFNN(2))/mean_ASMC(2);

% Control-effort change
effort_change = ...
    100*(mean_effort_RBFNN-mean_effort_ASMC)/mean_effort_ASMC;

fprintf('\n===== FINAL RESULTS =====\n');

fprintf('ASMC q1: %.6f +/- %.6f\n', ...
    mean_ASMC(1),std_ASMC(1));

fprintf('ASMC q2: %.6f +/- %.6f\n', ...
    mean_ASMC(2),std_ASMC(2));

fprintf('ASMC + RBFNN q1: %.6f +/- %.6f\n', ...
    mean_RBFNN(1),std_RBFNN(1));

fprintf('ASMC + RBFNN q2: %.6f +/- %.6f\n', ...
    mean_RBFNN(2),std_RBFNN(2));

fprintf('Improvement q1: %.2f %%\n',improvement_q1);
fprintf('Improvement q2: %.2f %%\n',improvement_q2);

fprintf('\nControl Effort:\n');

fprintf('ASMC: %.6f +/- %.6f N.m.s\n', ...
    mean_effort_ASMC,std_effort_ASMC);

fprintf('ASMC + RBFNN: %.6f +/- %.6f N.m.s\n', ...
    mean_effort_RBFNN,std_effort_RBFNN);

fprintf('Control effort change: %.2f %%\n',effort_change);

save('multiseed_results.mat', ...
    'ASMC_RMSE','RBFNN_RMSE', ...
    'ASMC_Effort','RBFNN_Effort', ...
    'mean_ASMC','mean_RBFNN', ...
    'std_ASMC','std_RBFNN', ...
    'mean_effort_ASMC','mean_effort_RBFNN', ...
    'std_effort_ASMC','std_effort_RBFNN');